package StepDefinations;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import PageObjects.LandingPage;
import io.cucumber.java.en.And;
//import PageObjects.Landingpage;
//import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utils.TestContextSetup;



public class LandingPagestepDefination {
	//private static final String ProductName = null;
	public WebDriver driver;
	public String landingPageProductName;
	public String offerPageProductName;
	TestContextSetup testContextSetup;
	LandingPage landingpage;
	
	public LandingPagestepDefination(TestContextSetup testContextSetup) {
		this.testContextSetup=testContextSetup;
		this.landingpage=testContextSetup.pageobjectmanager.getLandingPage();
	}
	
	
	@Given("User is on GreenCart Landing page")
	public void user_is_on_green_cart_landing_page() {
		Assert.assertTrue(landingpage.getTitleLandingpage().contains("GreenKart"));
	}
	
	
	@When("^User searched with Shortname (.+) and extracted actual name of product$")
	public void user_searched_with_shortname_and_extracted_actual_name_of_product(String shortName) throws InterruptedException {
	//this.landingpage=testContextSetup.pageobjectmanager.getLandingPage();
		landingpage.searchitem(shortName);
		 //testContextSetup.driver.findElement(By.xpath("//input[@type='search']")).sendKeys(shortName);
	   Thread.sleep(2000);
	   testContextSetup.landingPageProductName=  landingpage.getProductName().split("-")[0].trim();
	 System.out.println(landingPageProductName +" is extracted from Home page");
	   
	    
	}
	
	//And Added "3" items of the selected product to cart
	@When("Added {string} items of the selected product to cart")
	public void Added_items_product(String quantity)
	{
		landingpage.incrementQuantity(Integer.parseInt(quantity));
		landingpage.addtocart();
	}
	}
	

	
		
	
	



