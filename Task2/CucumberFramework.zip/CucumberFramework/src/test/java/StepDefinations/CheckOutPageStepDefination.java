package StepDefinations;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import PageObjects.CheckOutPage;
import PageObjects.LandingPage;
import PageObjects.PageObjectManager;
//import PageObjects.Landingpage;
//import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utils.TestContextSetup;



public class CheckOutPageStepDefination {
	//private static final String ProductName = null;
	public WebDriver driver;
	public String landingPageProductName;
	public String offerPageProductName;
	TestContextSetup testContextSetup;
	public CheckOutPage checkoutpage;
	
	public CheckOutPageStepDefination(TestContextSetup testContextSetup) {
		this.testContextSetup=testContextSetup;
		this.checkoutpage= testContextSetup.pageobjectmanager.getcheckoutpage();
		
	}
	
	
	@Then("verify user has ability to enter promo code and place the order")
	public void verify_user_has_ability_to_enter_promo_code_and_place_the_order()
	{

	

	
			Assert.assertTrue(checkoutpage.VerifyPromoBtn());
	Assert.assertTrue(checkoutpage.VerifyPlaceOrder());
		
	
	

	}
	
	@Then("^User proceeds to Checkout and  validate (.+) items in checkout page$")
	public void User_proceeds_to_checkout(String name)
	
	{
		checkoutpage.CheckoutItems();
		//Thread.sleep(2000);
		
	}
}
