package StepDefinations;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.gherkin.model.Scenario;
import com.mongodb.MapReduceCommand.OutputType;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import utils.TestContextSetup;

public class Hooks {
	//private static final org.openqa.selenium.OutputType OutputType.FILE = null;
	TestContextSetup testContextSetup;
	public Hooks(TestContextSetup testContextSetup) {
		
		this.testContextSetup=testContextSetup;
		
	}
	
	@After
	public void AfterScenario() throws IOException {
	
		testContextSetup.testBase.WebDrivermanager().quit();
		//driver.quit();

}
	
	
	
}
