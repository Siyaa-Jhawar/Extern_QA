package utils;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.PageObjectManager;

public class TestContextSetup {
	
	public WebDriver driver;
	public String landingPageProductName;
	public PageObjectManager pageobjectmanager;
	public TestBase testBase;
	public GenericUtils genericutils;
	//public ChromeDriver driver;
	//public ChromeDriver driver;
	public TestContextSetup() throws IOException {
		testBase=new TestBase();
		
		 pageobjectmanager = new PageObjectManager(testBase.WebDrivermanager());
		 genericutils=new GenericUtils(testBase.WebDrivermanager());
		
	}

}
