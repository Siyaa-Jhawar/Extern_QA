package PageObjects;

import org.openqa.selenium.WebDriver;

public class PageObjectManager {
	
	public LandingPage landingpage;
	public offerspage 	Offerspage;
	public WebDriver driver;
	public CheckOutPage checkoutpage;
	
	public PageObjectManager(WebDriver driver) {
		this.driver=driver;
	}
	
	

	public LandingPage getLandingPage()
	{
		landingpage=new LandingPage(driver);
		return landingpage;
	}
	public offerspage getofferspage()
	{
		 Offerspage = new offerspage(driver);
		 return Offerspage;
		
	}

	public CheckOutPage getcheckoutpage()
	{
		checkoutpage = new CheckOutPage(driver);
		 return checkoutpage;
		
	}






	

}
