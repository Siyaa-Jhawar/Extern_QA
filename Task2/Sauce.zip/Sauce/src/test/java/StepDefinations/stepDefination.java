package StepDefinations;

import java.nio.file.attribute.FileTime;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
//import io.cucumber.messages.types.Duration;

public class stepDefination {
	//private static final String EC = null;
	public WebDriver driver;
	@Given("navigate to Saucedemo page")
	public void navigate_to_saucedemo_page() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Arpit Jhawar\\Downloads\\chromedriver_win32\\chromedriver.exe");
		 driver=new ChromeDriver();
			//driver.manage().window().maximize();
		 driver.manage().window().maximize();
	       driver.get("https://www.saucedemo.com/");
		
	    
	}
	@When("user logging with username and password")
	public void user_logging_with_username_and_password()
	
	
	{
		driver.findElement(By.id("user-name"));
		   WebElement username = driver.findElement(By.id("user-name"));

       // WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
       // wait.until(ExpectedConditions.visibilityOfElementLocated(username));
		   driver.findElement(By.id("password"));
		   WebElement password=driver.findElement(By.id("password"));
		   WebElement login=driver.findElement(By.name("login-button"));
		   username.sendKeys("standard_user");
		   password.sendKeys("secret_sauce");
	
		login.click();
		
	
    }
	
	
	@Then("user is successful login")
	public void user_is_successful_login() {
		String actualUrl="https://www.saucedemo.com/inventory.html";
		String expectedUrl= driver.getCurrentUrl();
		Assert.assertEquals(expectedUrl,actualUrl);
	
	}
}