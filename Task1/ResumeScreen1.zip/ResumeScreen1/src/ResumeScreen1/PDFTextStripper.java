package ResumeScreen1;

public class PDFTextStripper {

	public String getText(PDDocument document) {
		// TODO Auto-generated method stub
		return null;
	}

}
