package ResumeScreen1;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;

import org.apache.pdfbox.text.PDFTextStripper;

public class ResumeScreen1 {

	

	public static void main(String[] args) throws IOException  {
		String currentDirectory = System.getProperty("user.dir");
		
		PDDocument document=PDDocument.load(new File(currentDirectory+"/src/ResumeScreen1/Resume1.pdf"));
		PDFTextStripper pdftext=new PDFTextStripper();
		String pdftextdata=pdftext.getText(document);
		System.out.println(pdftextdata);
		

	}

}
