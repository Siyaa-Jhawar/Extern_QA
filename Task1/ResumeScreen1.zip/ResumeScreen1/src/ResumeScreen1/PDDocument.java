package ResumeScreen1;

import java.io.File;

public class PDDocument {

	public static PDDocument load11(File file) {
		// TODO Auto-generated method stub
		return null;
	}

	public static PDDocument load1(File file) {
		// TODO Auto-generated method stub
		return null;
	}

	public static PDDocument load(File file) {
		// TODO Auto-generated method stub
		return null;
	}

}
