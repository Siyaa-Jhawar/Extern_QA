module ResumeScreen1 {
	requires org.apache.pdfbox;
}